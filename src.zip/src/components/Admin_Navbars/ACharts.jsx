import React, { useState,useEffect } from 'react';
import {Doughnut} from 'react-chartjs-2';



function ACharts() {

  const[data1,setData]=useState([]);
  useEffect(()=>{
    call();
  },[]);

  const call=async()=>{
    let token=localStorage.getItem("TOKEN");
    const response=await fetch("http://localhost:8765/attendance/getcount",{
      
      headers:{
        "Content-Type" : "application/json",
        "Accept":"application/json",
        "Authorization":"Bearer "+token
      }
    })
    if(response.ok){
      const data1=await response.json()
      setData(data1);
      console.log(data1);
    }
  }
  const data = {
    labels: [
      'Active',
      'InActive',
      'OnLeave'
    ],
    datasets: [{
      data: [data1.online, data1.inactive, data1.onLeave],
      backgroundColor: [
      '#FF6384',
      '#36A2EB',
      '#FFCE56'
      ],
      hoverBackgroundColor: [
      '#FF6384',
      '#36A2EB',
      '#FFCE56'
      ]
    }]
  };
     
    
  return (
    <div>
        
        <Doughnut data={data} />
    </div>
  );
}
export default ACharts;
import React, { Component } from "react";
import Flippy, { FrontSide, BackSide } from 'react-flippy';
import ACharts from './ACharts'
import ALineChart from './ALineChart'
import ASidebar from './ASidebar'
import Selection from'../Selection'

export default class Dashboard extends Component{
  constructor(props){
    super(props);
    this.state={
      data:[],
      isLoaded:true,
      isError:false
      
    }
  }
  async componentDidMount(){
    this.setState({isLoading:true})
    const response= await fetch("http://localhost:8765/attendance/getcount");
    if(response.ok){
      const data=await response.json()
      this.setState({data,isLoading:false})
      console.log(data);
    }
    else{
      this.setState({iserror:true,isLoading:false})
    }
  }
    render(){
        return (
            <>
        
 <ASidebar/>
<div className="row" style={{marginLeft:"200px"}}> 

<Flippy
    flipOnHover={false}
    flipOnClick={true}
    flipDirection="horizontal" 
    ref={(r) => this.flippy = r} 
    style={{ width: '200px', height: '150px', marginRight:"50px"}} 
  >
    <FrontSide
      style={{
        backgroundColor: ' #e6e6e6',
      }}
    >
      <div className="text-center" style={{marginTop:"40px"}}>Total Number</div>
    </FrontSide>
    <BackSide
      style={{ backgroundColor: '#ff9966'}}>
      <div style={{marginTop:"40px",marginLeft:"60px"}}>{this.state.data.total}</div>
    </BackSide>
  </Flippy>


    <Flippy
    flipOnHover={false} 
    flipOnClick={true} 
    flipDirection="horizontal" 
    ref={(r) => this.flippy = r} 
    style={{ width: '200px', height: '150px', marginLeft:"10px",marginRight:"50px"}} 
  >
    <FrontSide
      style={{
        backgroundColor: '#ff9966',
      }}
    >
      <div className="text-center" style={{marginTop:"40px"}}>Employee Online</div>
    </FrontSide>
    <BackSide
      style={{ backgroundColor: ' #e6e6e6' }}>
      <div style={{marginTop:"40px",marginLeft:"60px"}}>{this.state.data.online}</div>
    </BackSide>
  </Flippy>


  <Flippy
    flipOnHover={false} 
    flipOnClick={true} 
    flipDirection="horizontal" 
    ref={(r) => this.flippy = r} 
    style={{ width: '200px', height: '150px',marginRight:"50px" }} >
    <FrontSide
      style={{
        backgroundColor: '#e6e6e6',
      }}
    >
      <div className="text-center" style={{marginTop:"40px"}}>Employee InActive</div>
    </FrontSide>
    <BackSide
      style={{ backgroundColor: '#ff9966 '}}>
      <div style={{marginTop:"40px",marginLeft:"60px"}}>{this.state.data.inactive}</div>
    </BackSide>
  </Flippy>

  <Flippy
    flipOnHover={false} // default false
    flipOnClick={true} // default false
    flipDirection="horizontal" // horizontal or vertical
    ref={(r) => this.flippy = r} 
    style={{ width: '200px', height: '150px' }} 
  >
    <FrontSide
      style={{
        backgroundColor: '#ff9966',
      }}
    >
      <div className="text-center" style={{marginTop:"40px"}}>Employee On Leave</div>
    </FrontSide>
    <BackSide
      style={{ backgroundColor: '#e6e6e6'}}>
      <div style={{marginTop:"40px",marginLeft:"60px"}}>{this.state.data.onLeave}</div>
    </BackSide>
  </Flippy>

  <div className="row col-md-12 mt-5">Attendance Report</div>
  <div className="col-md-5 mt-5 mr-3 card"><ACharts/ ></div>
  <div className="col-md-5 mt-5 card"><ALineChart/ ></div>
  

<Selection/>
      </div>      
 
            </>
        )
    }
}
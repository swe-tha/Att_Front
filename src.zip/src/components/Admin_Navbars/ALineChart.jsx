import React, { useState,useEffect } from 'react';
import {Doughnut} from 'react-chartjs-2';



function ACharts() {

  const[data1,setData]=useState([]);
  useEffect(()=>{
    call();
  },[]);


  const call=async()=>{
    let token=localStorage.getItem("TOKEN");
    const response=await fetch("http://localhost:8765/attendance/getcount",{
      
      headers:{
        "Content-Type" : "application/json",
        "Accept":"application/json",
        "Authorization":"Bearer "+token
      }
    })
    if(response.ok){
      const data1=await response.json()
      setData(data1);
      console.log(data1);
    }
  }

  
  const data = {
    labels: [
      'Total',
      'OnLeave'
      
    ],
    datasets: [{
      data: [data1.total, data1.onLeave],
      backgroundColor: [
      '#6699ff',
      '#4dff4d'
      
      ],
      hoverBackgroundColor: [
      '#6699ff',
      // '#4dffff'
      '#4dff4d'
      ]
    }]
  };
     
    
  return (
    <div>
        
        <Doughnut data={data} />
    </div>
  );
}
export default ACharts;
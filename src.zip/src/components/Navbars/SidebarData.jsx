import React from "react";
import * as IoIcons from "react-icons/io";



export const SidebarData = [
  {
    title: "Home",
    path: "/EDashBoard",
    icon: <IoIcons.IoIosLeaf />,

  },
  {
    title: "My Profile",
    path: "/Emp_Profile_View",
    
    icon: <IoIcons.IoIosPerson />,
  },
  {
    title: "My Attendance",
    path: "/Myattendance",
    icon: <IoIcons.IoIosPaper />, 
  },
  {
    title: "AttendanceView",
    path: "/att",
    icon: <IoIcons.IoIosBook />,
  },
  {
    title: "My Leave Request",
    path: "/Leave",
    icon: <IoIcons.IoIosLeaf />,

  },
 
];
export default SidebarData;
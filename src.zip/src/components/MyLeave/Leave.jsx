import * as React from 'react';
import Sidebar from '../Navbars/Sidebar'
import './Leave.css'
import './ReactCal.css';
import Calendar from 'react-calendar'
import Selection from'../Selection'

import MyLeave from './MyLeave'
import TypesLeave from './TypesLeave'
import LeaveStatus from './LeaveStatus'

export default class DataTable extends React.Component{

  constructor(props){
    super(props);

    this.state={
      checkin_result:"",
      formValue:{
        fromDate:"",
        tillDate:"",
        purpose:"",
        typeOfLeave:""
        }
      }
    }

  handleChange=(event)=>{
    var name=event.target.name
    var value=event.target.value
    var {formValue}=this.state
    this.setState({formValue :{...formValue,[name]:value}})
  }

  submit=()=>{
    let token=localStorage.getItem("TOKEN");
    fetch("http://localhost:8765/attendance/applyleave/"+localStorage.getItem("UserId"),{
      method:"PUT",
      mode:"cors",
      body:JSON.stringify({
        "fromDate":this.state.formValue.fromDate,
        "tillDate":this.state.formValue.tillDate,
        "purpose":this.state.formValue.purpose,
        "typeOfLeave":this.state.formValue.typeOfLeave
      }),
      headers:{
        "Content-Type" : "application/json",
        "Accept":"application/json",
        "Authorization":"Bearer "+token

      }
    }).then(response=>{
      if(response.ok){
        response.text().then(json=>{
          console.log(json)
          this.setState({
            checkin_result:json,
            

          })
        })
      }
    }).catch(error=>{
      console.log("Error",error)
    })
    
    
  }

call=()=>{
  if(document.getElementById("MyLeave").style.display==="block")
  {
      (document.getElementById("MyLeave").style.display="none") 
  }
  else
      document.getElementById("MyLeave").style.display="block";
}

call1=()=>{
  if(document.getElementById("TypesLeave").style.display==="block"){
      (document.getElementById("TypesLeave").style.display="none") 
  }
  else
  document.getElementById("TypesLeave").style.display="block"
}
cals=()=>{
  if(document.getElementById("Calender").style.display==="block"){
      (document.getElementById("Calender").style.display="none") 
  }
  else
  document.getElementById("Calender").style.display="block"
}


  

  render(){
    return(
      <div>
        
        <Sidebar/>
      
      <div className="topic" style={{paddingBottom:"20px",marginLeft:"200px"}}>Leave</div>
      <div className="row" style={{marginLeft:"200px"}}>
      <div className="col-md-4 form-group">
      <label>From Date </label>
      <input type="date" className="form-control" placeholder="From Date" name="fromDate" onChange={this.handleChange}/>
      <label>To Date </label>
      <input type="date" className="form-control" placeholder="To Date" name="tillDate" onChange={this.handleChange}/>
      <label>Purpose</label>
      <input type="text" className="form-control" placeholder="Purpose" name="purpose" onChange={this.handleChange}/>
      <label>Type</label>
      <select id = "dropdown" className="form-control" name="typeOfLeave" onChange={this.handleChange}>
      <option value="">--SELECT--</option>
        <option value="Compensatory-off">Compensatory-off</option>
        <option value="Sick Leave">Sick Leave</option>
        <option value="Casual Leave">Casual Leave</option>
        <option value="Annual Leave">Annual Leave</option>
        <option value="Paternity/Maternity Leave">Paternity/Maternity Leave</option>
        <option value="Marriage Leave">Marriage Leave</option>
        <option value="LOP Leave">LOP Leave</option>
    </select>
    
    <button type="submit" className="btn mt-1" onClick={this.submit}>Apply Leave</button><br/>
    <span className="text-success col-md-12">{this.state.checkin_result}</span>
    <LeaveStatus/>
    </div>
      
    <div className="col-md-6  ml-5" style={{marginLeft:"100px"}}>
    {/* <Calendar /> */}
    <div id="Calender" className="react_calender " style= {{display:"none",color:"orange", fontSize:"15px",marginLeft:"100px",marginBottom:"100px"}}><Calendar/></div>
   <div id="MyLeave" style= {{display:"none"}}><MyLeave/></div>
   <div id="TypesLeave" style= {{display:"none"}}><TypesLeave/></div>
   <Selection/>

    </div>

    </div>
    <div className="" >
         <button type="button" className="att_btn position-absolute bottom-left"  onClick= {this.call }> Holiday Calender  </button>
      </div> 
      <div>
         <button type="button" className="att_btn1 position-absolute bottom-right" onClick= {this.call1} >Leave Record </button>
      </div> 
      <div>
         <button type="button" className="att_btn1 position-absolute bottom" onClick={this.cals}  >Calender </button>
      </div>
      </div>
    );
  }
}
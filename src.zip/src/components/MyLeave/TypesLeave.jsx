import * as React from 'react';
import Card from "react-bootstrap/Card";

export default class TypesLeave extends React.Component{
 
  constructor(props){
    super(props);
    this.state={
      data:[],
      isLoaded:true,
      isError:false
      
    }
  }

  async componentDidMount(){
  this.setState({isLoading:true})
  let token=localStorage.getItem("TOKEN");
  const response= await fetch("http://localhost:8765/attendance/getmyleaverecord/"+localStorage.getItem("UserId"),{
      
    headers:{
      "Content-Type" : "application/json",
      "Accept":"application/json",
      "Authorization":"Bearer "+token
    }})
  if(response.ok){
    const data=await response.json()
    this.setState({data,isLoading:false})

  }
  else{
    this.setState({iserror:true,isLoading:false})
  }
}

renderTableRows=()=>{
  return this.state.data.map(data=>{
    return(
      <tr key={data.leaveType}>
      <td className="text-center">{data.leaveType}</td>
      <td className="text-center">{data.available}</td>
      <td className="text-center">{data.noOfLeaveTaken}</td>
      <td className="text-center">{data.noOfLeaveLeft}</td>
    
    
      </tr>

    )
  })
}
renderTableHeader=()=>{
  return Object.keys(this.state.data[0]).map(attr=><th key={attr}>{attr.toUpperCase()}</th>)
}
  
render(){
  const{data,isLoaded,isError}=this.state;
  if(!isLoaded){
    return <div>Loding</div>
  }
  if(isError){
    return <div>Error</div>
  }
   return data.length>0
   ?(
     <>
     {/* <Sidebar/> */}
     <div style={{ width: '600px', marginLeft: '10px', borderRadius: '5px!important' }}>
     <Card.Body>
       <Card.Title>Leave Record</Card.Title>
     </Card.Body>
     <div style={{ height: 400, width: '100%' }}>
     {/* <tr>{this.renderTableRows()}</tr> */}
      {/* <DataGrid rows={this.renderTableRows()} columns={this.renderTableHeader()} pageSize={5} allowSorting={false} rowKey={1 }/> */}
     <table style={{border:"1px solid black",width:"500px"}} className="table-striped table-bordered" pagesize={1} >
       <thead>
         <tr style={{border:"1px solid black",textAlign:"center"}} className="text-center ml-5 ">
           {/* {this.renderTableHeader()} */}
           <th>Leave Type</th>
           <th>Available</th>
           <th>Taken</th>
           <th>Left</th>
         </tr>
         </thead>
         <tbody style={{border:"1px solid black"}}>
           {this.renderTableRows()}
         </tbody>
     </table>
     </div>
     </div>
     </>
   ):(

    <div>No users</div>

   )
}
}


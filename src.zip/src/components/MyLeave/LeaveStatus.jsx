import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Accordion from '@material-ui/core/Accordion';
import AccordionDetails from '@material-ui/core/AccordionDetails';
import AccordionSummary from '@material-ui/core/AccordionSummary';
import Typography from '@material-ui/core/Typography';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import PropTypes from 'prop-types';
import CircularProgress from '@material-ui/core/CircularProgress';
import Box from '@material-ui/core/Box';
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import Button from "@material-ui/core/Button";
import OpenInNewIcon from '@material-ui/icons/OpenInNew';
import Paper from "@material-ui/core/Paper";



function CircularProgressWithLabel(props) {
  return (
    <Box position="relative" display="inline-flex" >
      <CircularProgress variant="determinate" {...props} />
      <Box
        top={0}
        left={0}
        bottom={0}
        right={0}
        position="absolute"
        display="flex"
        alignItems="center"
        justifyContent="center"
      >
        <Typography variant="caption" component="div" color="textSecondary">{`${Math.round(
          props.value,
        )}%`}</Typography>
      </Box>
    </Box>
  );
}

CircularProgressWithLabel.propTypes = {
  value: PropTypes.number.isRequired,
};

const useStyles = makeStyles((theme) => ({
  root: {
    width: '100%',
  },
  heading: {
    fontSize: theme.typography.pxToRem(15),
    flexBasis: '33.33%',
    flexShrink: 0,
  },
  secondaryHeading: {
    fontSize: theme.typography.pxToRem(15),
    color: theme.palette.text.secondary,
  },
}));

export default function LeaveTypes() {
  const classes = useStyles();
  const [expanded, setExpanded] = React.useState(false);
  const [progress, setProgress] = React.useState(10);
  const [open, setOpen] = React.useState(false);

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };



  const handleChange = (panel) => (event, isExpanded) => {
    setExpanded(isExpanded ? panel : false);
  };

  React.useEffect(() => {
    const timer = setInterval(() => {
      setProgress((prevProgress) => (prevProgress >= 100 ? 0 : prevProgress + 10));
    }, 800);
    return () => {
      clearInterval(timer);
    };
  }, []);

  return (
    <div className={classes.root}>
     
      <Button onClick={handleClickOpen} color="primary">
            <Button color="primary">
            <Paper elevation={20}>  <OpenInNewIcon ></OpenInNewIcon> </Paper> 
            </Button>
          </Button>
          <Dialog
            disableBackdropClick
            disableEscapeKeyDown
            open={open}
            onClose={handleClose}
          >
            <DialogContent>
            <Accordion expanded={expanded === 'panel1'} onChange={handleChange('panel1')}  style={{width:500}}>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1bh-content"
          id="panel1bh-header"
        >
          {/* <Typography className={classes.heading} style={{}}>Sick Leave</Typography>
          <Typography className={classes.secondaryHeading}>03/04/2020 to 05/04/2020</Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography>
            <CircularProgressWithLabel value={progress} /> 
            <p style={{marginLeft:150}}> Effected by fever since a Week </p>
          </Typography>
        </AccordionDetails>
      </Accordion>
      <Accordion expanded={expanded === 'panel2'} onChange={handleChange('panel2')} style={{width:500}}>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel2bh-content"
          id="panel2bh-header"
        >
          <Typography className={classes.heading}>Festival Day</Typography>
          <Typography className={classes.secondaryHeading}>
            04/05/2020 to 06/05/2020
          </Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography>
          <CircularProgressWithLabel value={progress} /> 
            <p style={{marginLeft:150}}> we are having Diwali Festival  </p>
          </Typography>
        </AccordionDetails>
      </Accordion>
      <Accordion expanded={expanded === 'panel3'} onChange={handleChange('panel3')} style={{width:500}}>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel3bh-content"
          id="panel3bh-header"
        >
          <Typography className={classes.heading}>Dengue</Typography>
          <Typography className={classes.secondaryHeading}>
            05/08/2020 to 12/08/2020
          </Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography>
          <CircularProgressWithLabel value={progress} /> 
            <p style={{marginLeft:150}}>Suffering Dengue from a three days</p>
          </Typography>
        </AccordionDetails>
      </Accordion>
      <Accordion expanded={expanded === 'panel4'} onChange={handleChange('panel4')} style={{width:500}}>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel4bh-content"
          id="panel4bh-header"
        >
          <Typography className={classes.heading}>Head-Ache</Typography>
          <Typography className={classes.secondaryHeading}>
            09/09/2020 to 09/09/2020
          </Typography> */}

        </AccordionSummary>
        <AccordionDetails>
          <Typography>
          <CircularProgress />
          {/* <p style={{marginLeft:150}}>Head-Ache</p> */}
          </Typography>
        </AccordionDetails>
      </Accordion>
            </DialogContent>
            <DialogActions>
              <Button onClick={handleClose} color="primary">
                Ok
              </Button>
              </DialogActions>
          </Dialog>
    </div>
  );
}
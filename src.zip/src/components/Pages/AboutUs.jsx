import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import Paper from "@material-ui/core/Paper";
import AccountBoxIcon from "@material-ui/icons/AccountBox";
import LinkedInIcon from "@material-ui/icons/LinkedIn";
import Link from "@material-ui/core/Link";
import EmailIcon from "@material-ui/icons/Email";
import { NavLink} from "react-router-dom";
import {NavDropdown} from 'react-bootstrap';


const useStyles = makeStyles((theme) => ({
  root: {
    display: "flex",
    flexWrap: "wrap",
    "& > *": {
      margin: theme.spacing(1),
      width: theme.spacing(16),
      height: theme.spacing(16)
    },
    speedDial: {
      position: "absolute",
      bottom: theme.spacing(2),
      right: theme.spacing(2)
    }
  }
}));

export default function AboutUs() {
  const classes = useStyles();

  return (
    <div>
     <div className="row ">
      <img src="image/about.jpg" className="img-fluid"style={{width:"100%",height:"500px"}} alt="imag"/>
      </div>

      <div className="text-top">
      <NavDropdown title={localStorage.getItem("UserId")} style={{color:"white"}}>
            <NavDropdown.Item><NavLink className="navbar-item" activeClassName="is-active" to="/Sidebar" exact>Home</NavLink></NavDropdown.Item>
            <NavDropdown.Item><NavLink className="navbar-item" activeClassName="is-active" to="/ContactUs" exact>Contact</NavLink></NavDropdown.Item>
            <NavDropdown.Item><NavLink className="navbar-item" activeClassName="is-active" to="/AboutUs" exact> About </NavLink></NavDropdown.Item>
            <NavDropdown.Item><NavLink className="navbar-item" activeClassName="is-active" to="/changepassword" exact> Change Password</NavLink></NavDropdown.Item>
            <NavDropdown.Item><NavLink className="navbar-item" activeClassName="is-active" to="/logout" exact> Logout</NavLink></NavDropdown.Item>

          </NavDropdown>
      </div>
    <div className={classes.root}>
      <Paper
        elevation={3}
        style={{ marginLeft: 200, marginTop: -50, height: 150, width: 250 }}
      >
        <AccountBoxIcon
          color="primary"
          style={{ fontSize: 50 }}
        ></AccountBoxIcon>
        <p style={{ marginLeft: 90, marginTop: -30 }}> Swetha S </p>
        <p style={{ marginLeft: 10 }}>Frontend Developer</p>
        <Link href="https://www.linkedin.com/in/swetha-saravanan-81b460149">
          <LinkedInIcon
            color="primary"
            style={{ marginLeft: 30, fontSize: 40, marginTop: 10 }}
          ></LinkedInIcon>
        </Link>
        <Link href="https://sparshmail.ad.infosys.com/owa/auth/logon.aspx?replaceCurrent=1&url=https%3a%2f%2fsparshmail.ad.infosys.com%2fowa%2f">
          {" "}
          <EmailIcon
            color="primary"
            style={{ marginLeft: 10, fontSize: 40 }}
          ></EmailIcon>
        </Link>
      </Paper>
      <Paper elevation={3} style={{ marginTop: -50, height: 150, width: 250,marginLeft:50}}>
        <AccountBoxIcon
          color="orange"
          style={{ fontSize: 50, color: "orangered" }}
        >
          {" "}
        </AccountBoxIcon>
        <p style={{ marginLeft: 70, marginTop: -30 }}>Dev Dutta</p>
        <p style={{ marginLeft: 10 }}>Backend Developer</p>

        <Link href="https://www.linkedin.com/in/bhanu-pratap-354195175/">
          {" "}
          <LinkedInIcon
            style={{
              marginLeft: 30,
              fontSize: 40,
              marginTop: 10,
              color: "orangered"
            }}
          ></LinkedInIcon>
        </Link>

        <Link href="https://sparshmail.ad.infosys.com/owa/auth/logon.aspx?replaceCurrent=1&url=https%3a%2f%2fsparshmail.ad.infosys.com%2fowa%2f">
          {" "}
          <EmailIcon
            style={{ marginLeft: 10, fontSize: 40, color: "orangered" }}
          ></EmailIcon>
        </Link>
      </Paper>
      <Paper elevation={3} style={{ marginTop: -50, height: 150, width: 250,marginLeft:30}}>
        <AccountBoxIcon
          color="primary"
          style={{ fontSize: 50 }}
        ></AccountBoxIcon>
        <p style={{ marginLeft: 70, marginTop: -30 }}> Shiva charan</p>
        <p style={{ marginLeft: 10 }}>Frontend Developer</p>

        <Link href="https://www.linkedin.com/in/nallavelli-shiva-charan-reddy-51043316a/">
          <LinkedInIcon
            color="primary"
            style={{ marginLeft: 30, fontSize: 40, marginTop: 10 }}
          ></LinkedInIcon>
        </Link>
        <Link href="https://sparshmail.ad.infosys.com/owa/auth/logon.aspx?replaceCurrent=1&url=https%3a%2f%2fsparshmail.ad.infosys.com%2fowa%2f">
          <EmailIcon
            color="primary"
            style={{ marginLeft: 10, fontSize: 40 }}
          ></EmailIcon>
        </Link>
      </Paper>
      <Paper
        elevation={3}
        style={{ marginTop: 50, marginLeft: 200, height: 150, width: 250 }}
      >
        <AccountBoxIcon
          style={{ fontSize: 50, color: "orangered" }}
        ></AccountBoxIcon>
        <p style={{ marginLeft: 70, marginTop: -30 }}> Abhishek</p>
        <p style={{ marginLeft: 10 }}>Backend Developer</p>
        <Link href="https://www.linkedin.com/in/bhanu-pratap-354195175/">
          {" "}
          <LinkedInIcon
            style={{
              marginLeft: 30,
              fontSize: 40,
              marginTop: 10,
              color: "orangered"
            }}
          ></LinkedInIcon>
        </Link>
        <Link href="https://sparshmail.ad.infosys.com/owa/auth/logon.aspx?replaceCurrent=1&url=https%3a%2f%2fsparshmail.ad.infosys.com%2fowa%2f">
          {" "}
          <EmailIcon
            style={{ marginLeft: 10, fontSize: 40, color: "orangered" }}
          ></EmailIcon>
        </Link>
      </Paper>
      <Paper elevation={3} style={{ marginTop: 50, height: 150, width: 250,marginLeft: 50 }}>
        <AccountBoxIcon
          color="primary"
          style={{ fontSize: 50 }}
        ></AccountBoxIcon>
        <p style={{ marginLeft: 70, marginTop: -30 }}> Pallavi Sree</p>
        <p style={{ marginLeft: 10 }}>Frontend Developer</p>
        <Link href="https://www.linkedin.com/in/bhanu-pratap-354195175/">
          {" "}
          <LinkedInIcon
            color="primary"
            style={{ marginLeft: 30, fontSize: 40, marginTop: 10 }}
          ></LinkedInIcon>
        </Link>
        <Link href="https://sparshmail.ad.infosys.com/owa/auth/logon.aspx?replaceCurrent=1&url=https%3a%2f%2fsparshmail.ad.infosys.com%2fowa%2f">
          {" "}
          <EmailIcon
            color="primary"
            style={{ marginLeft: 10, fontSize: 40 }}
          ></EmailIcon>
        </Link>
      </Paper>
      
      <Paper
        elevation={3}
        style={{ marginTop: 50, marginLeft: 40, height: 150, width: 250 }}
      >
        <AccountBoxIcon
          style={{ fontSize: 50, color: "orangered" }}
        ></AccountBoxIcon>
        <p style={{ marginLeft: 70, marginTop: -30 }}> Talla Bhanu</p>
        <p style={{ marginLeft: 10 }}>Backend Developer</p>
        <Link href="https://www.linkedin.com/in/bhanu-pratap-354195175/">
          <LinkedInIcon
            style={{
              marginLeft: 30,
              fontSize: 40,
              marginTop: 10,
              color: "orangered"
            }}
          ></LinkedInIcon>
        </Link>
        <Link href="https://sparshmail.ad.infosys.com/owa/auth/logon.aspx?replaceCurrent=1&url=https%3a%2f%2fsparshmail.ad.infosys.com%2fowa%2f">
          <EmailIcon
            color="primary"
            style={{ marginLeft: 10, fontSize: 40, color: "orangered" }}
          ></EmailIcon>
        </Link>
      </Paper>
    </div>
    </div>
  );
}

import React, {Component} from 'react'
import Firebase from './Firebase'
import './FirebaseApp.css'
export class FirebaseApp extends Component{
    
  handleChange=(event)=>{
    var name=event.target.name
    var value=event.target.value
    var {formValue}=this.state
    this.setState({formValue :{...formValue,[name]:value}})
  }
  
    handleClick=() =>{
      const a=localStorage.getItem("UserId")
        var isAdmin="";
      fetch("http://localhost:8765/attendance/mobile/"+a,{
        method:"GET",
        mode:"cors",
        headers:{
          "Content-Type" : "application/json",
          "Accept":"application/json"
        }
      }).then(response=>{
        if(response.ok){
          response.text().then(json=>{
            isAdmin=json;
            console.log(isAdmin);
            let recaptcha=new Firebase.auth.RecaptchaVerifier('recaptcha',{'size': 'invisible'});
       
        let number=isAdmin;
        // let number="+918344947678";
       
        console.log(number);
        Firebase.auth().signInWithPhoneNumber(number,recaptcha).then(function(e){
            
            let code=prompt('Enter the OTP','');
            if(code == null) return;
            e.confirm(code).then(function(result){
                console.log(result.user,'user');
            document.querySelector('label').textContent=result.user.phoneNumber+ "Number Verified";
            console.log("Verified Successfully");
            
                  var a="/ChangePassword";
                  window.location.href=a;
                
            
            }).catch((error)=>{
                console.log(error)
            })
        })
            

          })
        }
      }).catch(error=>{
        console.log("Error",error)
      })

        

        
    }
    render(){
        return(
            <div className="row">
            <div className="col-md-6">
            <img className="home_image"
            src="https://www.sterlingfreeman.com/wp-content/uploads/2018/07/Employee-Background-Check.jpg
            " alt='poster'/> </div>
           
            <div className="col-md-6">
            <div className="firebase_card">
              <div className="top">
              <h3 style={{paddingTop:"50px",paddingBottom:"25px"}}>Reset & Verify !!</h3>
              
              </div>

              
              <div className="form-group">
              <span>{localStorage.getItem("UserId")}</span>
              <input type= "number" name="empId" onChange={this.handleChange} placeholder="Employee Id"/>
              <label>To Send an OTP </label>
              </div>
              

            <div>
            <label></label>
            <div id="recaptcha"></div>
            <button onClick={this.handleClick} className="fb_btn">Click here</button>
            </div>
            
            </div>
            </div>
            </div>
           
        )
    }

}
export default FirebaseApp
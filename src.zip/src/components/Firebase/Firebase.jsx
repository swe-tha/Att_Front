import Firebase from 'firebase'

const config={
    apiKey: "AIzaSyDgxjEINbHPTlsl2cXfdivQDcQs4jO9Lzs",
    authDomain: "attendancemanagement-816ab.firebaseapp.com",
    projectId: "attendancemanagement-816ab",
    storageBucket: "attendancemanagement-816ab.appspot.com",
    messagingSenderId: "376703492451",
    appId: "1:376703492451:web:f34fbf2da4ee4a897f7356"
}
Firebase.initializeApp(config);
export default Firebase
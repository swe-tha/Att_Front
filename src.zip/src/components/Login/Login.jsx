import 'bootstrap/dist/css/bootstrap.min.css'
import './Login.css'
import{Link,Redirect} from "react-router-dom"
import {useEffect,useState} from 'react'
import { useAuth } from "../../context/AuthContext"

export default function Login (){
    const [dayPart, setD]=useState('');
    const [userId, setUser]=useState('');
    const [password, setPassword]=useState('');
    const [result, setResult]=useState('');
    const [login, setLogin]=useState('');

    const {setAdmin}=useAuth()
    console.log(useAuth);
    
    useEffect(()=> {
      console.log("....."+userId);
      localStorage.setItem('UserId',userId)
    },[userId])

    
    
  
    useEffect(()=> {
      var today = new Date();
      var time = today.getHours();
    
      if(time <12)
        setD('Good Morning');
      else if(time <18)
        setD('Good Afternoon');
      else
        setD('Happy Evening');
    },[])

  
  function changeUser(event){
    setUser(event.target.value);
  }
  function changePassword(event){
    setPassword(event.target.value);
  }

  


  async function submitForm() {
      
      var isAdmin="";
      const res=await fetch("http://localhost:8765/attendance/signin",{
        method:"POST",
        
        body:JSON.stringify({
          "empName":userId,
          "password":password
        }),
        headers:{
          "Content-Type" : "application/json",
          "Accept":"application/json"
        }
      })
      // setUser(userId);
      let data=await res.json();
      if(data.roles[0]==="YES"){
        localStorage.setItem("TOKEN",data.token)
        localStorage.setItem("id",data.empName)
        setUser(data.id);
        setLogin("t");
        setAdmin(true);
        setResult("Logged In Successfully")
      }
      else if(data.roles[0]==="NO"){
        localStorage.setItem("TOKEN",data.token)
        localStorage.setItem("id",data.empName)
        setUser(data.id);
        setLogin("n");
        setAdmin(false);
        setResult("Logged In Successfully")
      }
      else
      setResult("UserName or Password Is Incorrect")
      
      console.log(data);
     return isAdmin; 

  }
  
 

  return(
      <>
      <div className="row">
          <div className="col-md-6 col-lg-6">
          <img className="login_image"
          src="https://www.naceweb.org/uploadedImages/images/2019/feature/the-four-career-competencies-employers-value-most.jpg
          " alt='login_poster'/> </div>
       
          <div className="col-md-6">
            <div className="login_card">
                    
              <h3 style={{paddingTop:"50px",paddingBottom:"25px"}}>Welcome Back!!</h3>
              {dayPart} User
              <br/><br/>
                      
              <form>
                <div className="form-group">
                <input type="text"  onChange= {(e) =>changeUser(e)} placeholder="Enter userId" required/>
                </div>
                      
                <div className="form-group">
                <input type="password" onChange={(e) =>changePassword(e)} placeholder="Enter password" required/>
                </div>
                

                      
                  
                <button type="button" className="login_btn" onClick= {()=>submitForm()  }>Login </button><br/><br></br> <br/>
                <Link to="/FirebaseApp"><button type="button" className="login_btn"  >Forget Password </button><br/><br/>
                </Link>
                
                <span className="text-danger" style={{display:"block"}}>{result}</span>
                  
                </form>
                {login==="t"?<Redirect to="/ASidebar"></Redirect>:(<>{login==="n"?<Redirect to="/Sidebar"></Redirect>:<></>}</>)}

                </div>

                </div>
        </div>
      
      </>
  )
}

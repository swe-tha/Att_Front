import 'bootstrap/dist/css/bootstrap.min.css'
import './ChangePassword.css'

import {useEffect,useState} from 'react'


export default function ForgetPassword (){
   
    const [passwordOne, setPasswordOne]=useState('');
    const [passwordTwo, setPasswordTwo]=useState('');
    const [result, setResult]=useState('');

    // console.log(passwordOne);
    // console.log(passwordTwo);
    useEffect(()=> {
  
    })
  
  function changePasswordOne(event){
    setPasswordOne(event.target.value);
  }
  function changePasswordTwo(event){
    setPasswordTwo(event.target.value);
  }
  
  
  function submit(){
    var isAdmin="";
    // let token=localStorage.getItem("TOKEN");
      fetch("http://localhost:8765/attendance/changePassword/"+localStorage.getItem("UserId"),{
        method:"POST",
        mode:"cors",
        body:JSON.stringify({
          "passwordOne":passwordOne,
          "passwordTwo":passwordTwo
        }),
        headers:{
          "Content-Type" : "application/json",
          "Accept":"application/json"
          // "Authorization":"Bearer "+token
        }
      }).then(response=>{
        if(response.ok){
          response.text().then(json=>{
            isAdmin=json;
            console.log("......",isAdmin);
            if(passwordOne===passwordTwo){
              var b="/";
               window.location.href=b;
               
          }
          else{
            setResult('Password mismatch')
          }

          })
        }
      }).catch(error=>{
        console.log("Error",error)
      })

    

    
  }
  return(
      <>
      
      <div className="row">
        <div className="col-md-6">
        <img className="forget_image"
          src="https://www.remichel.com/WebServices/Content/images/forgot_password.png
          " alt='changePassword_poster'/></div>
        <div className="col-md-6">
          <div className="pwd_card">
            <div className="top">
              <h3 style={{paddingTop:"50px",paddingBottom:"25px"}}>Change Password!!</h3>
              </div>
                        
              <form>
              <div className="form-group">
              <input type="password"  onChange= {(e) =>changePasswordOne(e)} placeholder="Enter password"/>
              </div>
              <div className="form-group mb-2">
              <input type="password"  onChange= {(e) =>changePasswordTwo(e)} placeholder="Retype the password"/>
              </div>

              <button type="button" onClick= {()=>submit() } className="forget_btn">Submit </button><br/><br/>
              <div className="text-danger">{result}</div>
              </form>
              </div>

              </div>
        </div>
      
      </>
  )
}

// import 'bootstrap/dist/css/bootstrap.min.css'
// import './ForgetPassword.css'

// import {useEffect,useState} from 'react'


// export default function ForgetPassword (){
   
//     const [userMobile, setChangeUserMobile]=useState('');
//     useEffect(()=> {
//       console.log(userMobile);
//     },[userMobile])
  
//   function changeUserMobile(event){
//     setChangeUserMobile(event.target.value);
//   }

  
//   function sendOTP(){
    
//     // fetch("http://localhost:8765/attendance/getPhNo",{
//     //   method:"POST",
//     //   mode:"cors",
//     //   body:JSON.stringify({
//     //     "mobileNo":userMobile,
        
//     //   }),
//     //   headers:{
//     //     "Content-Type" : "application/json",
//     //     "Accept":"application/json"
//     //   }
//     // }).then(response=>{
//     //   if(response.ok){
//     //     response.text().then(json=>{
//     //       isCorrect=json;
//     //       if(isCorrect=="YES"){
//     //         console.log("Correct No Sending OTP")
//             var b="/FirebaseApp";
//             window.location.href=b;
//     //         }
//     //       else {
//     //           console.log("Give the Registered Mobile Number")
//     //       }
              

//     //     })
//     //   }
//     // }).catch(error=>{
//     //   console.log("Error",error)
//     // })


    
//   }
//   return(
//       <>
      
//       <div className="row">
//           <div className="col-md-6">
//           <img className="forget_image"
                    
//           src="https://www.remichel.com/WebServices/Content/images/forgot_password.png
//           " alt='some value'/></div>
           
//           <div className="col-md-6">
  
//             <div className="forget_card">
//             <div className="top">
//               <h3 style={{paddingTop:"50px",paddingBottom:"25px"}}>Change Password!!</h3>
//             </div>

//             <form>
//             <div className="form-group">
//               <input type="number"  onChange= {(e) =>changeUserMobile(e)} placeholder="Enter Mobile No"/></div>
//               <br/>
   
//               <button type="button" onClick= {()=>sendOTP()  } className="forget_btn">sendOTP </button><br/><br/>
                      
//               </form>
//           </div>

//           </div>
//         </div>
      
//       </>
//   )
// }

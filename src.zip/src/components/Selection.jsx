import React, { Component } from "react";
import Chatbot from "../components/Pages/Chatbot";


export default class Selection extends Component{

    call=()=>{
        if(document.getElementById("Chatbot").style.display==="block")
        {
            (document.getElementById("Chatbot").style.display="none") 
        }
        else
            document.getElementById("Chatbot").style.display="block";
      }
    render(){
        return (
            <>
            <button style={{"position":"fixed",
    "bottom": "10px",
    "right": "100px",
    "marginLeft":"700px" }} onClick= {this.call }>+</button>
    <div id="Chatbot" style= {{display:"none","position":"fixed",
    "bottom": "10px",
    "right": "120px",
    "marginLeft":"700px"}}><Chatbot/></div>
            </>
        )
    }
}
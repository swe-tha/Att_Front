import * as React from 'react';
import ASidebar from '../Admin_Navbars/ASidebar'



import Card from "react-bootstrap/Card";


export default class Attendance_View extends React.Component{
 

    constructor(props){
      super(props);
      this.state={
        data:[],
        isLoaded:true,
        isError:false
        
      }
    }

    async componentDidMount(){
    this.setState({isLoading:true})
    let token=localStorage.getItem("TOKEN");
    const response= await fetch("http://localhost:8765/attendance/getallattendance",{
      
      headers:{
        "Content-Type" : "application/json",
        "Accept":"application/json",
        "Authorization":"Bearer "+token
      }
    })
    if(response.ok){
      const data=await response.json()
      this.setState({data,isLoading:false})

    }
    else{
      this.setState({iserror:true,isLoading:false})
    }
  }

  renderTableRows=()=>{
    return this.state.data.map(data=>{
      return(
        <tr key={data.sNo}>
        <td className="text-center">{data.sNo}</td>
        <td className="text-center">{data.empId}</td>
        {/* <td className="text-center">{data.attendanceId}</td> */}
        <td className="text-center">{data.atDate}</td>
        <td className="text-center">{data.inTime}</td>
        <td className="text-center">{data.outTime}</td>
        <td className="text-center">{data.noOfHours}</td>
        </tr>

      )
    })
  }
  renderTableHeader=()=>{
    return Object.keys(this.state.data[0]).map(attr=><th key={attr}>{attr.toUpperCase()}</th>)
  }
    
  render(){
    const{data,isLoaded,isError}=this.state;
    if(!isLoaded){
      return <div>Loding</div>
    }
    if(isError){
      return <div>Error</div>
    }
     return data.length>0
     ?(
       <>
       <ASidebar/>
       <div style={{ width: '700px', marginLeft: '250px', borderRadius: '5px!important' }}>
       <Card.Body>
         <Card.Title>Attendance View</Card.Title>
       </Card.Body>
       <div style={{ height: 400, width: '100%' }}>
       <table style={{border:"1px solid black", width:"700px"}} className="table-striped table-bordered" pagesize={1} >
         <thead>
           <tr style={{border:"1px solid black",textAlign:"center"}} className="text-center ml-5 ">
             <th>S.No</th>
             <th>Employee Id</th>
             <th>Date</th>

             <th>Check In Time</th>
             <th>Check Out Time</th>
             <th>Working Hours</th>

           </tr>
           </thead>
           <tbody style={{border:"1px solid black"}}>
             {this.renderTableRows()}
           </tbody>
       </table>
       </div>
       
       </div>
       
       </>
     ):(

      <div>No users</div>

     )
  }
}







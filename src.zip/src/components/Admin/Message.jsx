import emailjs from "emailjs-com";
import React from 'react';

export default function ContactUs() {

    function sendEmail(e) {
        e.preventDefault();
        const templateParams={
            from_name:"shwethasara27@gmail.com",
            to_name:"shwethasara27@gmail.com,swetha11.trn@infosys.com"
          
        }

        emailjs.send('service_kqw74sz', 'template_rwcw0b4', templateParams, 'user_KOGfmBJRc2B3cgoNiKTxi')
        .then((result) => {
            console.log(result.text);
        }, (error) => {
            console.log(error.text);
        });
       
    }

    return(
        <div>
           <form>
                    
                     
                <input type="submit" className="btn btn-info" value="Send Message" onClick={sendEmail}></input>
              
                </form>
        </div>
    )
}
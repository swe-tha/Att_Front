import React, { Component } from "react";
import ASidebar from '../Admin_Navbars/ASidebar';
import emailjs from "emailjs-com";


export default class Add_Employee extends Component{

  constructor(props){
    super(props);
    this.state={
      data:[],
      isLoaded:true,
      isError:false,
      output:'',
      formValue:{
        empId:"",
        empName:"",
        email:"",
        jobRole:"",
        department:"",
        mobileNo:"",
        password:"",
        status:"",
        isAdmin:"",
        results:[]
        },
        formErrorMessage:{
          empId:"",
          empName:"",
          email:"",
          jobRole:"",
          department:"",
          mobileNo:"",
          password:"",
          status:"",
          isAdmin:"",
        },
        formValid:{
          empId:false,
          empName:false,
          email:false,
          jobRole:false,
          department:false,
          mobileNo:false,
          password:false,
          status:false,
          isAdmin:false,
  
        },
        successMessage:"",
        errorMessage:"",
        
      
      
    }
  }



  handleChange=(event)=>{
    var name=event.target.name
    var value=event.target.value
    var {formValue}=this.state
    this.setState({formValue :{...formValue,[name]:value}})
    this.validateField(name,value)
  }

  validateField=(name,value)=>{
    let fieldValidationErrors=this.state.formErrorMessage;
    let formValid=this.state.formValid;
    switch(name){
      case("empId"):
      if(value===""){
        fieldValidationErrors.empId = "Field Required ";
        formValid.empId = false;
      }
      else{
        fieldValidationErrors.empId = "";
        formValid.empId = true;
      }
      break;

      case "empName":
      if (value === "") {
        fieldValidationErrors.empName = "Field Required ";
        formValid.empName = false;
      } 
      else {
        fieldValidationErrors.empName = "";
        formValid.empName = true;
      }
      break;
      case "password":
      if (value === "") {
        fieldValidationErrors.empName = "Field Required ";
        formValid.empName = false;
      } 
      else {
        fieldValidationErrors.empName = "";
        formValid.empName = true;
      }
      break;
      case "email":
      const regexp="([a-z]+)(@infosys.com)";
      if (value === "") {
        fieldValidationErrors.email = "Field Required ";
        formValid.email = false;
      } 
      else if(!value.match(regexp)){
        fieldValidationErrors.email = "Invalid format";
        formValid.email = false;
      }
      else {
        fieldValidationErrors.email = "";
        formValid.email = true;
      }
      break;

      case "mobileNo":
      const mregexp="(^[+](91)[789][0-9]{9})";
      if (value === "") {
        fieldValidationErrors.mobileNo = "Field Required ";
        formValid.mobileNo = false;
      } 
      else if(!value.match(mregexp)){
        fieldValidationErrors.mobileNo = "Invalid format";
        formValid.email = false;
      }
      else {
        fieldValidationErrors.mobileNo = "";
        formValid.mobileNo = true;
      }
      break;
      default:
      break;

    }
    
    this.setState({
    formErrorMessage: fieldValidationErrors,
    formValid: formValid,
    successMessage: "",
    errorMessage: ""

});
  }

  handleSubmit=(event)=>{
    event.preventDefault();
  }

  save=()=>{
    var isAdmin="";
    let token=localStorage.getItem("TOKEN");
    fetch("http://localhost:8765/attendance/employee",{
      method:"POST",
      mode:"cors",
      body:JSON.stringify({
        "empId":this.state.formValue.empId,
        "empName":this.state.formValue.empName,
        "password":this.state.formValue.password,
        "jobRole":this.state.formValue.jobRole,
        "email":this.state.formValue.email,
        
        "department":this.state.formValue.department,
        "status":this.state.formValue.status,
        "mobileNo":this.state.formValue.mobileNo,
        
        "isAdmin":this.state.formValue.isAdmin


      }),
      headers:{
        "Content-Type" : "application/json",
        "Accept":"application/json",
        "Authorization":"Bearer "+token
      }
    }).then(response=>{
      if(response.ok){
        response.text().then(json=>{
          isAdmin=json;
          console.log("ccd",isAdmin)
          this.setState({
            output:json
          })
        })
      }
    }).catch(error=>{
      console.log("Error",error)
    })
    

  }
  sendEmail=()=>{
    const templateParams={
        from_name:"shwethasara27@gmail.com",
        to_name:this.state.formValue.email,
        employeeId:this.state.formValue.empId,
        password:this.state.formValue.password
    }

    emailjs.send('service_kqw74sz', 'template_rwcw0b4', templateParams, 'user_KOGfmBJRc2B3cgoNiKTxi')
    .then((result) => {
        console.log(result.text);
    }, (error) => {
        console.log(error.text);
    });

  }
render(){
  return (
  <>         
   <ASidebar/>
    <div style={{ display: 'flex', justifyContent: 'space-evenly' }}>
   
    <div className='ml-5'>
    <div style={{ width: 600, marginTop: 20}} type='info' className="col-md-12 ">
      <div className="card-body">
      <div className="topic" style={{paddingBottom:"20px"}}>Add Employee</div>
         <div class="form-group" style={{marginLeft:"50px"}} >
         <form onSubmit={this.handleSubmit}>
         <div>
         <label> Employee Id</label>
          <input type="text" name="empId" value={this.state.data.empId} onChange={this.handleChange} className="form-control " /> <br />
          <span name="empIdError" className="text-danger">{this.state.formErrorMessage.empId}</span>
          </div>
          <div>
          <label> Given Name</label>
          <input type="text" name="empName" placeholder={this.state.data.empName} onChange={this.handleChange}  className="form-control" /> <br />
          <span name="empNameError" className="text-danger">{this.state.formErrorMessage.empName}</span>
          </div>
          <div>
          <label>Password</label>
          <input type="password" name="password" placeholder={this.state.data.password} onChange={this.handleChange}  className="form-control" /> <br />
          </div>
          <div>
          Email:<input type="email" id="email" placeholder={this.state.data.email} name="email" onChange={this.handleChange} className="form-control" /> <br />
          <span name="emailError" className="text-danger">{this.state.formErrorMessage.email}</span>
          </div>
          <label>Department</label>
      <select id = "dropdown" className="form-control" name="department"  placeholder={this.state.data.department} onChange={this.handleChange} className="form-control">
      <option value="">--SELECT--</option>
        <option value="ETA">ETA</option>
        <option value="Web Development">Web Development</option>
        <option value="Testing">Testing</option>
      </select>

    <label>JobRole</label>
      <select id = "dropdown" className="form-control" name="jobRole"  placeholder={this.state.data.jobRole}  onChange={this.handleChange} className="form-control">
      <option value="">--SELECT--</option>
        <option value="Front End Developer">Front End Developer</option>
        <option value="Back End Developer">Back End Developer</option>
        <option value="Tester">Tester</option>
      </select>
    <div>
        <label> Mobile No</label>
        <input type="text" name="mobileNo" placeholder={this.state.data.mobileNo} onChange={this.handleChange} className="form-control" /> <br />
        <span name="mobileNoError" className="text-danger">{this.state.formErrorMessage.mobileNo}</span>
    </div>     
    <label>Status</label>
      <select id = "dropdown" className="form-control" name="status"  placeholder={this.state.data.status}  onChange={this.handleChange} className="form-control">
      <option value="">--SELECT--</option>
      <option value="ACTIVE">ACTIVE</option>
      <option value="INACTIVE">INACTIVE</option>     
      </select>
    <label>IsAdmin</label>
    <select id = "dropdown" className="form-control" name="isAdmin"  placeholder={this.state.data.isAdmin}  onChange={this.handleChange} className="form-control">
      <option value="">--SELECT--</option>
        <option value="YES">YES</option>
        <option value="NO">NO</option>     
    </select>
    </form>

      <span className="text-success">{this.state.output}</span></div>
      </div>
      <div style={{marginLeft:"50px"}}>
        <button className="attr_btn ml-4 mr-5" onClick= {this.save} type="submit" >Save</button>
        {/* <button className="attr_btn ml-4 mr-5" onClick= {this.sendEmail} type="submit" >Notify Employee</button> */}
        
      </div>
     
    </div>

  </div>
  <div >
    <div >
      
 
   
    </div>

  </div>
</div>
            </>
        )
    }
}
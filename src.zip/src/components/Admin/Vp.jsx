import * as React from 'react';
import ASidebar from '../Admin_Navbars/ASidebar'

import emailjs from "emailjs-com";

import Card from "react-bootstrap/Card";


export default class Employee_All extends React.Component{
 

    constructor(props){
      super(props);
      this.state={
        data:[],
        isLoaded:true,
        isError:false
        
      }
    }

    async componentDidMount(){
    this.setState({isLoading:true})
    let token=localStorage.getItem("TOKEN");
    const response= await fetch("http://localhost:8765/attendance/employeeleaves",{
      
      headers:{
        "Content-Type" : "application/json",
        "Accept":"application/json",
        "Authorization":"Bearer "+token
      }
    })
    if(response.ok){
      const data=await response.json()
      this.setState({data,isLoading:false})
      console.log(",,,",data);
    }
    else{
      this.setState({iserror:true,isLoading:false})
    }
  }

  
  renderTableRows=()=>{
    return this.state.data.map(data=>{
      return(
        <tr key={data.sno}>
        <td className="text-center">{data.sno}</td>
        <td className="text-center">{data.empId}</td>
        <td className="text-center" >{data.leaverecordId}</td>
        <td className="text-center">{data.fromDate}</td>
        <td className="text-center">{data.tillDate}</td>
        <td className="text-center">{data.purpose}</td>
        <td className="text-center">{data.typeOfLeave}</td>
        <td className="text-center">{data.noOfLeaves}</td>
        
        <td><button  className="text-center" onClick={()=>this.accept(data.leaverecordId,data.status,data.fromDate,data.tillDate,data.purpose)}>Accept</button> <button onClick={()=>this.reject(data.leaverecordId,data.status)}>Reject</button></td>
        <td className="text-center">{data.status}</td>

        </tr>

      )
    })
  }
  accept(a,b,c,d,e){
    let token=localStorage.getItem("TOKEN");
    fetch("http://localhost:8765/attendance/statusLeave",{
      method:"PUT",
      mode:"cors",
      body:JSON.stringify({
        "leaverecordId":a,
        "status":"ACCEPT"
      }),
      headers:{
        "Content-Type" : "application/json",
        "Accept":"application/json",
        "Authorization":"Bearer "+token
      }
    }).then(response=>{
      if(response.ok){
        response.text().then(json=>{
          console.log("djfjeg",json)
          this.setState({
            checkin_result:json,
          })
        })
      }
    }).catch(error=>{
      console.log("Error",error)
    })
    const templateParams={
      // from_name:"shwethasara27@gmail.com",
      to_name:"shwethasara27@gmail.com",
      status:"accepted",
      from_date:c,
      till_date:d,
      purpose:e
      
  }

  emailjs.send('service_8axhykr', 'template_vql030t', templateParams, 'user_qObHerQS0fC95a2Icr5SJ')
  .then((result) => {
      console.log(result.text);
  }, (error) => {
      console.log(error.text);
  });

  }

  reject(a,b){
    let token=localStorage.getItem("TOKEN");
    fetch("http://localhost:8765/attendance/statusLeave",{
      method:"PUT",
      mode:"cors",
      body:JSON.stringify({
        "leaverecordId":a,
        "status":"REJECT"
      }),
      headers:{
        "Content-Type" : "application/json",
        "Accept":"application/json",
        "Authorization":"Bearer "+token
      }
    }).then(response=>{
      if(response.ok){
        response.text().then(json=>{
          console.log("djfjeg",json)
          this.setState({
            checkin_result:json,
          })
        })
      }
    }).catch(error=>{
      console.log("Error",error)
    })
    const templateParams={
      // from_name:"shwethasara27@gmail.com",
      to_name:"shwethasara27@gmail.com",
      status:"rejected"
      
  }

  emailjs.send('service_8axhykr', 'template_vql030t', templateParams, 'user_qObHerQS0fC95a2Icr5SJ')
  .then((result) => {
      console.log(result.text);
  }, (error) => {
      console.log(error.text);
  });

  }

  
  renderTableHeader=()=>{
    return Object.keys(this.state.data[0]).map(attr=><th key={attr}>{attr.toUpperCase()}</th>)
  }
    
  render(){
    const{data,isLoaded,isError}=this.state;
    if(!isLoaded){
      return <div>Loding</div>
    }
    if(isError){
      return <div>Error</div>
    }
     return data.length>0
     ?(
       <>
       <ASidebar/>
       <div style={{ width: '700px', marginLeft: '200px', borderRadius: '5px!important' }}>
       <Card.Body>
       <div className="topic" style={{paddingBottom:"20px"}}>Leave Request</div>
         {/* <Card.Title>Employee List</Card.Title> */}
       </Card.Body>
       <div style={{ height: 400, width: '100%' }}>
       <table style={{border:"1px solid black", width:"1000px"}} className="table-striped table-bordered" pagesize={1} >
         <thead>
           <tr style={{border:"1px solid black",textAlign:"center"}} className="text-center ml-5 ">
           <th>S.No</th>
           <th>Employee Id</th>
           <th>Id leave</th>
             <th>From Date</th>

             <th>Till Date</th>
             <th>Purpose</th>
             <th>Type of Leave</th>
             <th>No of Leaves</th>
             <th>Leave Request</th>
             <th>Leave Status</th>

           </tr>
           </thead>
           <tbody style={{border:"1px solid black"}}>
             {this.renderTableRows()}
             
           </tbody>
       </table>
       </div>
       </div>
       </>
     ):(

      <div>No users</div>

     )
  }
}







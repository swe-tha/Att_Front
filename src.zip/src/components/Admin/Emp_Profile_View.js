import React, { Component } from "react";
import Sidebar from '../Navbars/Sidebar';

import {Link} from 'react-router-dom';
import Selection from'../Selection'


export default class Emp_Profile extends Component{

  constructor(props){
    super(props);
    this.state={
      data:[],
      isLoaded:true,
      isError:false,
      output:[],
      formValue:{
        empName:"",
        email:"",
        jobRole:"",
        department:"",
        mobileNo:"",
        results:[]
        },
        formValue:{
          empId:"",
          empName:"",
          email:"",
          jobRole:"",
          department:"",
          mobileNo:"",
          password:"",
          status:"",
          isAdmin:"",
          results:[]
          },
          formErrorMessage:{
            empId:"",
            empName:"",
            email:"",
            jobRole:"",
            department:"",
            mobileNo:"",
            password:"",
            status:"",
            isAdmin:"",
          },
          formValid:{
            empId:false,
            empName:false,
            email:false,
            jobRole:false,
            department:false,
            mobileNo:false,
            password:false,
            status:false,
            isAdmin:false,
    
          },
          successMessage:"",
          errorMessage:"",
          
        
      
    }
  }

  async componentDidMount(){
    this.setState({isLoading:true})
    let token=localStorage.getItem("TOKEN");
    const response= await fetch("http://localhost:8765/attendance/getemployee/"+localStorage.getItem("UserId"),{
      
      headers:{
        "Content-Type" : "application/json",
        "Accept":"application/json",
        "Authorization":"Bearer "+token
      }
    })
    if(response.ok){
      const data=await response.json()
      this.setState({data:data,isLoading:false})
      console.log(data);

    }
    else{
      this.setState({iserror:true,isLoading:false})
    }
  }

  handleChange=(event)=>{
    var name=event.target.name
    var value=event.target.value
    var {formValue}=this.state
    this.setState({formValue :{...formValue,[name]:value}})
    this.validateField(name,value)
  }

  validateField=(name,value)=>{
    let fieldValidationErrors=this.state.formErrorMessage;
    let formValid=this.state.formValid;
    switch(name){
      

      case "email":
      const regexp="([a-z]+)(@infosys.com)";
       if(!value.match(regexp)){
        fieldValidationErrors.email = "Invalid format";
        formValid.email = false;
      }
      else {
        fieldValidationErrors.email = "";
        formValid.email = true;
      }
      break;

      case "mobileNo":
      const mregexp="(^[+](91)[789][0-9]{9})";
      if (value === "") {
        fieldValidationErrors.mobileNo = "Field Required ";
        formValid.mobileNo = false;
      } 
      else if(!value.match(mregexp)){
        fieldValidationErrors.mobileNo = "Invalid format";
        formValid.email = false;
      }
      else {
        fieldValidationErrors.mobileNo = "";
        formValid.mobileNo = true;
      }
      break;
      default:
      break;

    }
    
    this.setState({
    formErrorMessage: fieldValidationErrors,
    formValid: formValid,
    successMessage: "",
    errorMessage: ""

});
  }

  save=()=>{
    var isAdmin="";
    let token=localStorage.getItem("TOKEN");
    fetch("http://localhost:8765/attendance/employeedetails/"+localStorage.getItem("UserId"),{
      method:"PUT",
      mode:"cors",
      body:JSON.stringify({
        "empName":this.state.formValue.empName,
        "email":this.state.formValue.email,
        "jobRole":this.state.formValue.jobRole,
        "department":this.state.formValue.department,
        "mobileNo":this.state.formValue.mobileNo,
       
        

      }),
      headers:{
        "Content-Type" : "application/json",
        "Accept":"application/json",
        "Authorization":"Bearer "+token
      }
    }).then(response=>{
      if(response.ok){
        response.text().then(json=>{
          isAdmin=json;
          console.log("Checkout",isAdmin)
          this.setState({
            output:json
          })
        })
      }
    }).catch(error=>{
      console.log("Error",error)
    })

  }


render(){
  return (
  <>         
   {/* {this.state.checked?<ASidebar/>:<Sidebar/>} */}
   <Sidebar/>
    <div style={{ display: 'flex', justifyContent: 'space-evenly' }}>
   
    <div className='ml-5'>
    <div style={{ width: 600, marginTop: 20}} type='info' className="col-md-12 ">
      <div className="card-body">
      <div className="topic" style={{paddingBottom:"20px"}}>Edit Details </div>
         <div class="form-group" style={{marginLeft:"50px"}} >
         <form onSubmit={this.handleSubmit}>
         <div>
         <label> Employee Id</label>
          <input type="text" name="empId" value={this.state.data.empId} onChange={this.handleChange} className="form-control " /> <br />
          <span name="empIdError" className="text-danger">{this.state.formErrorMessage.empId}</span>
          </div>
          <div>
          <label> Given Name</label>
          <input type="text" name="empName" placeholder={this.state.data.empName} onChange={this.handleChange}  className="form-control" /> <br />
          <span name="empNameError" className="text-danger">{this.state.formErrorMessage.empName}</span>
          </div>
        
          <div>
          Email:<input type="email" id="email" placeholder={this.state.data.email} name="email" onChange={this.handleChange} className="form-control" /> <br />
          <span name="emailError" className="text-danger">{this.state.formErrorMessage.email}</span>
          </div>

          <div>
          MobileNo:<input type="number" id="mobileNo" placeholder={this.state.data.mobileNo} name="mobileNo" onChange={this.handleChange} className="form-control" /> <br />
          <span name="mobileNoError" className="text-danger">{this.state.formErrorMessage.mobileNo}</span>
          </div>
      
    <label>Department</label>
      <select id = "dropdown" className="form-control" name="department"  placeholder={this.state.data.department} onChange={this.handleChange} className="form-control">
      <option value="">--SELECT--</option>
        <option value="ETA">ETA</option>
        <option value="Web Development">Web Development</option>
        <option value="Testing">Testing</option>
    </select>

    <label>JobRole</label>
      <select id = "dropdown" className="form-control" name="jobRole"  placeholder={this.state.data.jobRole}  onChange={this.handleChange} className="form-control">
      <option value="">--SELECT--</option>
        <option value="Front End Developer">Front End Developer</option>
        <option value="Back End Developer">Back End Developer</option>
        <option value="Tester">Tester</option>
    </select>
    
        </form>
        <span className="text-success">{this.state.output}</span>
        </div>
      </div>
      <div style={{marginLeft:"50px"}}>
        <button className="attr_btn ml-4 mr-5" onClick= {this.save} type="submit" >Save</button>
        
      </div>
    </div>

  </div>
  <div >
    <div >
      
    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS38zu52WbPVB1MolgBHgBo9YBigWNHTjPYOw&usqp=CAU" alt='some value' className="mt-5" />      
{/* <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT7R1-iBTMTHEyl99YywmKIg6nL7a2vV24bqQ&usqp=CAU" alt='some value' className="mt-5" /> */}
      <div className="cardBody">
        <p>{this.state.data.empName} </p>
      </div>
      
        <button className="attr_btn">Edit</button>
        <Link to="/Profile"><button className="attr_btn">View</button></Link>
   
    </div>

  </div>
  <Selection />
</div>
            </>
        )
    }
}
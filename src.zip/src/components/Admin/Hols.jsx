import React, { Component } from "react";
import ASidebar from '../Admin_Navbars/ASidebar';



export default class Emp_Profile extends Component{

  constructor(props){
    super(props);
    this.state={
      data:[],
      isLoaded:true,
      isError:false,
      output:"",
      formValue:{
        holidayId:"",
        holidayDate:"",
        holidayDesc:"",
        results:[]
        },
        formErrorMessage:{
          holidayId:"",
          holidayDate:"",
          holidayDesc:"",
        },
        formValid:{
          holidayId:false,
          holidayDate:false,
          holidayDesc:false,
          
  
        },
        successMessage:"",
        errorMessage:"",

    }
  }



  handleChange=(event)=>{
    var name=event.target.name
    var value=event.target.value
    var {formValue}=this.state
    this.setState({formValue :{...formValue,[name]:value}})
    this.validateField(name,value)
    
  }
  validateField=(name,value)=>{
    let fieldValidationErrors=this.state.formErrorMessage;
    let formValid=this.state.formValid;
    switch(name){
      case "holidayDate":
      const regexp="";
       if(!value.match(regexp)){
        fieldValidationErrors.holidayDate = "Invalid format";
        formValid.holidayDate = false;
      }
      else {
        fieldValidationErrors.holidayDate = "";
        formValid.holidayDate = true;
      }
      break;
      case("holidayId"):
      if(value===""){
        fieldValidationErrors.holidayId = "Field Required ";
        formValid.holidayId = false;
      }
      else{
        fieldValidationErrors.holidayId = "";
        formValid.holidayId = true;
      }
      break;
      default:
      break;
    }}

  save=()=>{
    var isAdmin="";
    let token=localStorage.getItem("TOKEN");
    fetch("http://localhost:8765/attendance/holidayupdate",{
      method:"PUT",
      mode:"cors",
      body:JSON.stringify({
        "holidayId":this.state.formValue.holidayId,
        "holidayDate":this.state.formValue.holidayDate,
        "holidayDesc":this.state.formValue.holidayDesc
      }),
      headers:{
        "Content-Type" : "application/json",
        "Accept":"application/json",
        "Authorization":"Bearer "+token
      }
    }).then(response=>{
      if(response.ok){
        response.text().then(json=>{
          isAdmin=json;
          console.log("Checkout",isAdmin)
          this.setState({
            output:json
          })
        })
      }
    }).catch(error=>{
      console.log("Error",error)
    })

  }


render(){
  return (
  <>         
   <ASidebar/>
    <div style={{ display: 'flex', justifyContent: 'space-evenly' }}>
   
    <div className='ml-5'>
    <div style={{ width: 600, marginTop: 20}} type='info' className="col-md-12 ">
      <div className="card-body">
      <div className="topic" style={{paddingBottom:"20px"}}>Update Holidays</div>
         <div class="form-group" style={{marginLeft:"50px"}} >
         <form onSubmit={this.handleSubmit}>
         <div>
         <label> Holiday Id</label>
          <input type="text" name="holidayId" value={this.state.data.holidayId} onChange={this.handleChange} className="form-control " /> <br />
          <span name="holidayIdError" className="text-danger">{this.state.formErrorMessage.holidayId}</span>
          </div>
          <div>
          <label>Holiday Date</label>
          <input type="date" name="holidayDate" placeholder={this.state.data.holidayDate} onChange={this.handleChange}  className="form-control" /> <br />
          <span name="holidayDateError" className="text-danger">{this.state.formErrorMessage.holidayDate}</span>
          </div>
      
          <label>Holiday Description</label>
          <select id = "dropdown" className="form-control" name="holidayDesc" onChange={this.handleChange}>
        <option value="">--SELECT--</option>
        <option value="Makara Sankranthi">Makara Sankranthi</option>
        <option value="Republic Day">Republic Day</option>
        <option value="Good Friday">Good Friday</option>
        <option value="Ugadi">Ugadi</option>
        <option value="Ramzan">Ramzan</option>
        <option value="Varamahalakshmi">Varamahalakshmi</option>
        <option value="Ganesha Chaturthi">Ganesha Chaturthi</option>
        <option value="Vijaya Dashami">Vijaya Dashami</option>
        <option value="Kannada Rajyotsava">Kannada Rajyotsava</option>
        <option value="Deepavali">Deepavali</option>
        
        
    </select>
      
        <span className="text-success">{this.state.output}</span>
        </form></div>
      </div>
      <div style={{marginLeft:"50px"}}>
        <button className="attr_btn ml-4 mr-5" onClick= {this.save} type="submit" >Save</button>
        
      </div>
    </div>

  </div>
  <div >
   

  </div>
  
</div>
            </>
        )
    }
}
import * as React from 'react';
import ASidebar from '../Admin_Navbars/ASidebar'
import {Link} from 'react-router-dom'

import Card from "react-bootstrap/Card";


export default class Employee_All extends React.Component{
 

    constructor(props){
      super(props);
      this.state={
        data:[],
        isLoaded:true,
        isError:false
        
      }
    }

    async componentDidMount(){
    this.setState({isLoading:true})
    
    let token=localStorage.getItem("TOKEN");
    const response= await fetch("http://localhost:8765/attendance/getallemployee",{
      
      headers:{
        "Content-Type" : "application/json",
        "Accept":"application/json",
        "Authorization":"Bearer "+token
      }
    })
    if(response.ok){
      const data=await response.json()
      this.setState({data,isLoading:false})

    }
    else{
      this.setState({iserror:true,isLoading:false})
    }
  }

  renderTableRows=()=>{
    return this.state.data.map(data=>{
      return(
        <tr key={data.empId}>
        <Link to="/Profiles" style={{color:"orange"}}><td className="text-center">{data.empId}</td></Link>
        <td className="text-center">{data.empName}</td>
        {/* <td className="text-center">{data.attendanceId}</td> */}
        {/* <td className="text-center">{data.department}</td> */}
        <td className="text-center">{data.jobRole}</td>
        {/* <td className="text-center">{data.mobileNo}</td> */}
        {/* <td className="text-center">{data.email}</td> */}
        <td className="text-center">{data.status}</td>
        </tr>

      )
    })
  }
  renderTableHeader=()=>{
    return Object.keys(this.state.data[0]).map(attr=><th key={attr}>{attr.toUpperCase()}</th>)
  }
    
  render(){
    const{data,isLoaded,isError}=this.state;
    if(!isLoaded){
      return <div>Loding</div>
    }
    if(isError){
      return <div>Error</div>
    }
     return data.length>0
     ?(
       <>
       <ASidebar/>
       <div style={{ width: '700px', marginLeft: '200px', borderRadius: '5px!important' }}>
       <Card.Body>
         <Card.Title>Employee List</Card.Title>
       </Card.Body>
       <div style={{ height: 400, width: '100%' }}>
       <table style={{border:"1px solid black", width:"800px",marginLeft:"50px"}} className="table-striped  "  pagesize={1} >
         <thead>
           <tr style={{border:"1px solid black",textAlign:"center"}} className="text-center ml-5 ">
             
             <th>Employee Id</th>
             <th>Employee Name</th>
             {/* <th>Department</th> */}

             <th>Job Role</th>
             {/* <th>Contact No</th> */}
             {/* <th>Email</th> */}
             <th>Status</th>

           </tr>
           </thead>
           <tbody style={{border:"1px solid black"}}>
             {this.renderTableRows()}
           </tbody>
       </table>
       </div>
       </div>
       </>
     ):(

      <div>No users</div>

     )
  }
}







import React from 'react';

import Sidebar from '../Navbars/Sidebar'
import './MyAttendance.css'
import Selection from'../Selection'

export default class MyAttendance extends React.Component{
  constructor(props){
    super(props);

    this.state={
      date:new Date().getFullYear()+'/'+(new Date().getMonth()+1)+'/'+new Date().getDate(),
      isButtonDisabled:false,
      isButtonDisabled1:true,
      isButtonDisabled3:true,
      formValue:{
      breakTime:"",
      reason:"",
      arr:[],
      results:[]
      }
    }
  }
  
  handleChange=(event)=>{
    var name=event.target.name
    var value=event.target.value
    var {formValue}=this.state
    this.setState({formValue :{...formValue,[name]:value}})
  }

  workingHours=()=>{
    
    // const [data,setData]=useSatate([]);
    let token=localStorage.getItem("TOKEN");
    fetch("http://localhost:8765/attendance/attendancedetail/"+localStorage.getItem("UserId"),{
      
      headers:{
        "Content-Type" : "application/json",
        "Accept":"application/json",
        "Authorization":"Bearer "+token
      }
    })
    .then((response)=> response.json()).then((json)=>{
        console.log("nnnn",json);
        
        this.setState({
          results:json,
          checkInTime:json.checkInTime,
          checkOutTime:json.checkOutTime,
          totalBreaks:json.totalBreaks,
          workingHours:json.workingHours

        });
        
      })  
    
  }

  break=()=>{
    let token=localStorage.getItem("TOKEN");
    fetch("http://localhost:8765/attendance/break/"+localStorage.getItem("UserId"),{
        method:"PUT",
        mode:"cors",
        body:JSON.stringify({
          "breakTime":this.state.formValue.breakTime,
          "reason":this.state.formValue.reason
        }),
        headers:{
          "Content-Type" : "application/json",
          "Accept":"application/json"
        }
      }).then(response=>{
        if(response.ok){
          response.text().then(json=>{
            console.log(json)
            this.setState({
              result:json
            })
          })
        }
      }).catch(error=>{
        console.log("Error",error)
      })
  }

  show=()=>{
    let token=localStorage.getItem("TOKEN");
    fetch("http://localhost:8765/attendance/checkin/"+localStorage.getItem("UserId"),{
      method:"PUT",
      mode:"cors",
      headers:{
        "Content-Type" : "application/json",
        "Accept":"application/json",
        "Authorization":"Bearer "+token
      }
    }).then(response=>{
      if(response.ok){
        response.text().then(json=>{
          console.log(json)
          this.setState({
            checkin_result:json,
            

          })
        })
      }
    }).catch(error=>{
      console.log("Error",error)
    })
    this.setState({
      isButtonDisabled: true,
      isButtonDisabled1:false,
      isButtonDisabled3:false
    });
    setTimeout(
      function(){
        this.enable()
      }.bind(this),1000 * 60 * 60 * 24
    );
    
     
  }


  show1=()=>{
    var isAdmin="";
    let token=localStorage.getItem("TOKEN");
    fetch("http://localhost:8765/attendance/checkout/"+localStorage.getItem("UserId"),{
      method:"PUT",
      mode:"cors",
      headers:{
        "Content-Type" : "application/json",
        "Accept":"application/json",
        "Authorization":"Bearer "+token
      }
    }).then(response=>{
      if(response.ok){
        response.text().then(json=>{
          isAdmin=json;
          console.log("Checkout",isAdmin)
          this.setState({
            checkout_result:json
          })
        })
      }
    }).catch(error=>{
      console.log("Error",error)
    })

    this.setState({
      isButtonDisabled1: true,
      isButtonDisabled3: true,

    });
    setTimeout(
      function(){
        this.enable()
      }.bind(this),1000 * 60 * 60 * 24
    );
  }
    enable(){
      this.setState({
        isButtonDisabled:false
      });
    }

    

  render(){
    return(
      <div>
        <div>
          <Sidebar/>
        </div>
        <div className="attendance">
        <div className="topic" style={{paddingBottom:"20px"}}>My Attendance </div>
        <div className="row">
                  
            <div className="col-md-4">
            <div className="card">
            <h2 className="card-header" >Attendance for {this.state.date.toString()} </h2>
            <div className="card-body">
            <button className="attr_btn" onClick={this.show} disabled={this.state.isButtonDisabled}>Check In</button>
            <button className="attr_btn" onClick={this.show1} disabled={this.state.isButtonDisabled1}>Check Out</button>

            <table className="table mt-5" >
            <thead>
            <tr>
              <th >CheckIn</th>
              <th >CheckOut</th>
            </tr>
            </thead>
            <tbody>
              <tr>
                <td>{this.state.checkin_result}</td>
                <td>{this.state.checkout_result}</td>
              </tr>
            </tbody>
            </table>

            </div>
            </div>
          </div>

          <div className="col-md-4">
            <div className="card">
            <h2 className="card-header">Get refreshed!!</h2>
              <div className="card-body">
              <div className="form-group">
                <label>Type Of Break</label>
                <input type="text" className="form-control text-line" name="reason" onChange={this.handleChange} placeholder="type of break"/>
                <label className="pt-3">Time In Minutes</label>
                  <input type="number" className="form-control text-line" name="breakTime" onChange={this.handleChange} placeholder="time in minutes"/>
              </div>
              <br/>
                      
              <button className="attr_btn" onClick={this.break} disabled={this.state.isButtonDisabled3}>Break</button>
              
              </div>
              </div>
              </div>

              <div className="col-md-4">
              <div className="card">
              <h2 className="card-header">Working Hours</h2>
              {/* {this.state.result} */}
              <div className="card-body">
              <table className="table mt-5" >
              <thead>
                <tr>
                  <th >CheckIn</th>
                  <th >Break</th>
                  <th>CheckOut</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                <td>{this.state.checkin_result}</td>
                  <td>{this.state.result}</td>
                  
                  <td>{this.state.checkout_result}</td>
                </tr>

              </tbody>
              </table>
              <button className="attr_btn"
               onClick={this.workingHours} 
               >Working Hours</button>
              </div>
              </div>
              </div>

              <div className="col-md-12 mt-3">
              <div className="card" id="workingHours">
              <h2 className="card-header">Working Hours</h2>
              {/* {this.state.result} */}
              <div className="card-body">
              <table className="table mt-1" >
              <thead>
                <tr>
                  <th >CheckIn Time</th>
                  <th >Break</th>
                  <th>CheckOut Time</th>
                  <th>Working Hours</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  {/* const arr=JSON.parse(this.state.results) */}
                  <td>{this.state.checkInTime}</td>
                  <td>{this.state.totalBreaks}</td>
                  <td>{this.state.checkOutTime}</td>
                  
                  <td>{this.state.workingHours}</td>
                  
                </tr>

              </tbody>
              </table>
            
              </div>
              
              </div>
              </div>

              <Selection />
              </div>
              </div>
              

        </div>
  
    );
  }
}
    
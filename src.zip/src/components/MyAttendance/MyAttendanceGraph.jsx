import React from 'react';
import {Line} from 'react-chartjs-2';

const state = {
  labels: ['12', '1', '2','3','4','5','6','7','8','9','10','11','12','1', '2','3','4','5','6','7','8','9','10','11'],
  datasets: [
    {
      label: 'Working Hours',
      fill: false,
      lineTension: 0.5,
      backgroundColor: 'rgba(75,192,192,1)',
      borderColor: 'rgba(0,0,0,1)',
      borderWidth: 2,
      data: [0,0,0,0,0,0,0,0,0,100,100,50,0,0,0,100,100,100,0,0,0,0,0,0]
    }
  ]
}

export default class MyAttendanceGraph extends React.Component {
  render() {
    return (
      <div>
        <Line
          data={state}
          options={{
            title:{
              display:true,
              text:'Average Working Hours',
              fontSize:20
            },
            legend:{
              display:true,
              position:'right'
            }
          }}
        />
      </div>
    );
  }
}
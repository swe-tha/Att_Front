import React,{useContext,useState, useEffect} from 'react'

const AuthContext = React.createContext()

export function useAuth(){
    return useContext(AuthContext)
}

export function AuthProvider({children}){
    const [isAdmin,setIsAdmin]=useState(false);
    const [userType,setUserType]=useState(true);
    function setAdmin(val){
        if(val===true)
            setIsAdmin(true);
        if(val===false)
            setIsAdmin(false);
    }
    function setUser(val){
        setUserType(val)
    }
    useEffect(() => {
        if(isAdmin===false)
            setUserType(false)
    },[isAdmin])

    const value={
        isAdmin,setAdmin,userType,setUser
    }


    return (
        <AuthContext.Provider value={value}>
          {children}
        </AuthContext.Provider>
    )
}
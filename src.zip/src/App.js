import './App.css';

import Login from './components/Login/Login';
import {BrowserRouter as Router,Route, Switch} from 'react-router-dom';
import Selection from'./components/Selection'
import AdminDashboard  from './components/Dashboard/AdminDashboard';
import ForgetPassword  from './components/Login/ForgetPassword';
import Firebase from'./components/Firebase/Firebase'
import FirebaseApp from'./components/Firebase/FirebaseApp'
import ChangePassword from'./components/Login/ChangePassword'
import MyAttendance from'./components/MyAttendance/MyAttendance'
import MyAttendanceGraph from'./components/MyAttendance/MyAttendanceGraph'
import MyLeave from './components/MyLeave/MyLeave'
import LeaveStatus from './components/MyLeave/LeaveStatus'
import TypesLeave from './components/MyLeave/TypesLeave'
// import Sidebar from './components/Navbars/Sidebar'
import SidebarData from './components/Navbars/SidebarData'
import SubMenu from './components/Navbars/SubMenu'
import ASubMenu from './components/Admin_Navbars/ASubMenu'
import ASidebarData from './components/Admin_Navbars/ASidebarData'
import Emp_Profile_View from './components/Admin/Emp_Profile_View'
import Hols from './components/Admin/Hols'
import AddEmployee from './components/Admin/AddEmployee'
import Message from './components/Admin/Message'
import Employee_All from './components/Admin/Employee_All'
import Attendance_View from './components/Admin/Attendance_View'
import Dashboard from './components/Admin_Navbars/Dashboard'
import EDashboard from './components/Navbars/EDashboard'
import ACharts from './components/Admin_Navbars/ACharts'
import ALineChart from './components/Admin_Navbars/ACharts'


import Leave from './components/MyLeave/Leave'
import Att from './components/Attendance/Att'
import Profiles from './components/Admin/Profiles'

import Profile from './components/Profile/Profile'


import AboutUs from "./components/Pages/AboutUs";

import { ContactUs} from "./components/Pages/ContactUs";
import Chatbot from "./components/Pages/Chatbot";

import Vp from "./components/Admin/Vp";

import {AuthProvider} from './context/AuthContext';

function App() {
  
  return (
    <div className="App">
    <Router>
      <AuthProvider>
      <Switch>
        <Route path="/" exact component={()=> <Login/>} />
        <Route path="/Logout" exact component={()=> <Login/>} />
        <Route path="/AdminDashboard" exact component={()=> <AdminDashboard/>} />
        <Route path="/ForgetPassword" exact component={()=> <ForgetPassword/>} />
        <Route path="/Firebase" exact component={()=> <Firebase/>} />
        <Route path="/FirebaseApp" exact component={()=> <FirebaseApp/>} />
        <Route path="/ChangePassword" exact component={()=> <ChangePassword/>} />
        <Route path="/MyAttendance" exact component={()=> <MyAttendance/>} />
        <Route path="/MyAttendanceGraph" exact component={()=> <MyAttendanceGraph/>} />
        <Route path="/MyLeave" exact component={()=> <MyLeave/>} />
        <Route path="/LeaveStatus" exact component={()=> <LeaveStatus/>} />
        <Route path="/TypesLeave" exact component={()=> <TypesLeave/>} />



        <Route path="/Sidebar" exact component={()=> <EDashboard/>} />
        <Route path="/SidebarData" exact component={()=> <SidebarData/>} />
        <Route path="/SubMenu" exact component={()=> <SubMenu/>} />
        <Route path="/ASidebar" exact component={()=> <Dashboard/>} />
        <Route path="/ASidebarData" exact component={()=> <ASidebarData/>} />
        <Route path="/ASubMenu" exact component={()=> <ASubMenu/>} />

        <Route path="/Profile" exact component={()=> <Profile/>} />
        <Route path="/AboutUs" exact component={AboutUs} />
        <Route path="/ContactUs" exact component={ContactUs} />
        <Route path="/Chatbot" exact component={Chatbot} />
        
        <Route path="/Leave" exact component={Leave} />
        <Route path="/Att" exact component={Att} />
        <Route path="/Selection" exact component={Selection}/>
        <Route path="/Emp_Profile_View" exact component={Emp_Profile_View}/>
        <Route path="/Hols" exact component={Hols}/>
        <Route path="/AddEmployee" exact component={AddEmployee}/>
        <Route path="/Employee_All" exact component={Employee_All}/>
        <Route path="/Attendance_View" exact component={Attendance_View}/>
        <Route path="/Dashboard" exact component={Dashboard}/>
        <Route path="/EDashboard" exact component={EDashboard}/>
        <Route path="/ACharts" exact component={ACharts}/>
        <Route path="/ALineChart" exact component={ALineChart}/>
        <Route path="/Profiles" exact component={Profiles}/>
        <Route path="/Message" exact component={Message}/>

        <Route path="/Vp" exact component={Vp}/>
        
        
      </Switch>
      </AuthProvider>
    </Router>
    
    </div>
  );
}

export default App;
